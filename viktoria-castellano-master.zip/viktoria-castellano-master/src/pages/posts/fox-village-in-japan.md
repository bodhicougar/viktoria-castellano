---
title: Willkommen! Ich möchte mich vorstellen...
subtitle: >-
  Apparently, Japan is covered in magical and irresistibly cute animal
  sanctuaries.
date: '2021-05-16'
thumb_img_path: /images/IMG_7347.jpg
thumb_img_alt: A red fox sitting on a meadow
content_img_path: /images/_ADR5848.jpg
excerpt: >-
  Apparently, Japan is covered in magical and irresistibly cute animal
  sanctuaries. The Shrines of Ise have been celebrated as the prototype of
  Japanese architecture.
seo:
  type: stackbit_page_meta
  title: Fox Village In Japan
  description: >-
    Apparently, Japan is covered in magical and irresistibly cute animal
    sanctuaries.
  extra:
    - name: 'og:type'
      value: article
      keyName: property
    - name: 'og:title'
      value: Fox Village In Japan
      keyName: property
    - name: 'og:description'
      value: >-
        Apparently, Japan is covered in magical and irresistibly cute animal
        sanctuaries.
      keyName: property
    - name: 'og:image'
      value: images/10.jpg
      keyName: property
      relativeUrl: true
    - name: 'twitter:card'
      value: summary_large_image
    - name: 'twitter:title'
      value: Fox Village In Japan
    - name: 'twitter:description'
      value: >-
        Apparently, Japan is covered in magical and irresistibly cute animal
        sanctuaries.
    - name: 'twitter:image'
      value: images/10.jpg
      relativeUrl: true
template: post
---
Mein Vorstellungsvideo:

<https://www.youtube.com/watch?v=lRIr6VgJkpE>
